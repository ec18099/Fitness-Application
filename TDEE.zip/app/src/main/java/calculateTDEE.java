public class calculateTDEE {
        double height,weight;
        int age;
        String sex;
        double TDEE;
        String activityLevels;
        double ac;

        public calculateTDEE() {
            this.height=height;
            this.weight = weight;
            this.age = age;
            this.sex = sex;
        }

        public void setTDEE(double height,double weight,int age,String sex,String activityLevels)
        {
            if (activityLevels == "little/no exercise")
            {
                this.ac = 1.2;
            }
            else if (activityLevels == "light exercise")
            {
                this.ac = 1.375;
            }
            else if(activityLevels == "moderate")
            {
                this.ac = 1.55;
            }
            else if(activityLevels == "heavy")
            {
                this.ac = 1.725;
            }
            else if(activityLevels == "extreme")
            {
                this.ac = 1.9;
            }


            if (sex == "female")
            {
                this.TDEE= (655 + (9.6*weight)+(1.8*height)-(4.7*age))* ac;
            }
            else if (sex == "male")
            {
                this.TDEE = (66+(13.7*weight)+(5*height)-(6.8*age))*ac;
            }
        }

        public double getTDEE()
        {
            return this.TDEE;
        }

}
